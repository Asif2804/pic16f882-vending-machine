// Filename:VendingMachine.c
// Version: 1.0
// Date: 10.04.23
// Author: Asif Hussain

#pragma config FOSC = INTRC_NOCLKOUT // Oscillator Selection bits
#pragma config WDTE = OFF // Watchdog Timer Enable bit
#pragma config PWRTE = OFF // Power-up Timer Enable bit
#pragma config MCLRE = ON // RE3/MCLR pin function select bit
#pragma config CP = OFF // Code Protection bit
#pragma config CPD = OFF // Data Code Protection bit
#pragma config BOREN = OFF // Brown Out Reset Selection bits
#pragma config IESO = OFF // Internal External Switchover bit
#pragma config FCMEN = OFF // Fail-Safe Clock Monitor Enabled bit
#pragma config LVP = OFF // Low Voltage Programming Enable bit
#pragma config BOR4V = BOR40V // Brown-out Reset Selection bit
#pragma config WRT = OFF // Flash Program Memory Self Write Enable bits

#include <xc.h> // Required by compiler, PIC specific definitions
#include "LCDdrive882.h" // Header file needed to access to LCD custom library
#include "ADClib882.h" // Header file for ADC library

#define _XTAL_FREQ 4000000 // MCU clock speed - required for delay macros


// Function prototypes
void config (void);
void drinkDisplay(void);
void drinkSelectionMode(void);
void coinInsertionMode(void);
void dispenseDrinkMode(void);
void dispenseChangeMode(void);
void drinkReadyMode(void);
void alarmMode(void);

void timer0_Delay(unsigned char delay_length);
void timer1_Delay(void);

char beverages = 1;
char drink_dispensed = 0;
signed char price;
signed char newPrice;
char x;
char change_due;

void config (void) 
{     
    ANSEL = 0x00; // All pins as digital outputs
    ANSELH = 0x00;
    TRISA = 0x00; // Configure PORTA
    PORTA = 0x00;
    PORTB = 0x00;
    TRISB = 0x07; // Configure PORTB as input
    IOCB = 0x07; // Enable interrupt-on-change for RB0, RB1, RB2
    INTCON = 0x48;
    
    INTCONbits.GIE = 0; // Disable interrupts during configuration
    INTCONbits.RBIE = 1;
    INTCONbits.RBIF = 0;
    INTCONbits.GIE = 1;
    
    LCD_initialise();
    beverages = 0;
}

void main(void) 
{     
   config();
   while(PORTBbits.RB1 == 0)
   {   
       LCD_cursor(0, 0);
       LCD_puts("Select Drink:");
       drinkDisplay(); // trigger drink display mode               
   }
   
   LCD_clear();
   while(PORTBbits.RB1);
   
   while(price > 0)
   {      
       LCD_cursor(0, 0);
       LCD_puts("Insert Coin:");
       LCD_cursor(0, 1);
       LCD_display_value(price);
       LCD_cursor(4, 1);
       coinInsertionMode();// trigger Coin Insertion mode
   } 
    
   LCD_clear();
   dispenseDrinkMode();// trigger Drink dispensing mode
   LCD_cursor(0, 1);
    
   if(change_due > 0)
   {
       dispenseChangeMode(); // trigger Drink dispensing mode
        drinkReadyMode();
   }
   else
   {   
       
       drinkReadyMode();     
   }
}

void drinkDisplay(void)
{
   LCD_cursor(0, 1); // Move the cursor to the 2nd line
    
    const char beverageNr1[] = {"Coke 80p"};
    const char beverageNr2[] = {"Lemonade 80p"};
    const char beverageNr3[] = {"Orange Juice 60p"};
    const char beverageNr4[] = {"Water 50p"};
    
    switch(beverages) 
    {
    case 0:
         
        LCD_puts(beverageNr1);
        price = 80;
    break;
    
    case 1:
        
        LCD_puts(beverageNr2);
        price = 80;
    break;
    
    case 2:
        LCD_cursor(0, 1); // Move the cursor to the 2nd line
        LCD_puts(beverageNr3);
        price = 60;
    break;
    
    case 3:
        LCD_puts(beverageNr4);
        price = 50;
    break;
    }
      
    if(INTCONbits.RBIF)
    {
        if(PORTBbits.RB0)
        {

                LCD_clear();
                beverages++; // Here needs some work
        }
        
        INTCONbits.RBIF = 0;
    }

    if(beverages > 3)
    {
        beverages = 0;
    }
            
}


void timer0_Delay(unsigned char delay_length)
{
   
    unsigned char preload = 131; // TMR0 preload variable (derived from Ex3)
    unsigned short i; // Loop index variable
    
    //Timer0 setup
    OPTION_REGbits.T0CS = 0; // Set clock source to internal (timer mode)
    OPTION_REGbits.PSA = 0; // Set prescaler to Timer 0
    OPTION_REGbits.PS = 3; // Set prescaler bits to 111 for 1:256

    for(i=0;i<500*delay_length;i++) // Loop to cascade several short delays together
    {
        TMR0 = preload; // Preload timer0
        while(!INTCONbits.TMR0IF); // Delay loop: Wait until TMR0 overflows
        INTCONbits.TMR0IF = 0; // Reset overflow flag, TMR0IF
    }
}

void Timer1Delay(unsigned char delay)
{
    T1CON = 0x30;
    TMR1H = 0xCF2C; // Preload
    TMR1L = 0x00;
    for(unsigned char i = 0; i < 10 * delay; i++);
    {
        T1CONbits.TMR1ON = 0; // Reset overflow flag  T1CONbits.TMR1ON = 1;
        T1CONbits.TMR1ON = 1;
        while(!PIR1bits.TMR1IF); // Delay routine - wait for overflow
        PIR1bits.TMR1IF = 0; // Reset overflow flag
        
    }
}

void coinInsertionMode(void)
{
    
    LCD_cursor(0, 1); // Move the cursor to the 2nd line
	 
       
		// Subtract 10p for each RB0 press
		if (PORTBbits.RB0)
		{
            while(PORTBbits.RB0);
			price = price - 10;
		
            
		}	
        INTCONbits.RBIF = 0;
		// Subtract 20p for each RB1 press
		if (PORTBbits.RB1)
		{
            while(PORTBbits.RB1);
			price = price - 20;
		
           
		}
        INTCONbits.RBIF = 0;
        // Subtract 50p for each RB1 press
		if (PORTBbits.RB2)
		{
            while(PORTBbits.RB2);
			price = price - 50;
           
		}
    INTCONbits.RBIF = 0;
    
      change_due = 0 - price;  
        
    
}

void dispenseDrinkMode(void)
{      
    // Set RA0 high to turn on the LED for 5 seconds
   
    PORTA= 1;
   
    // Show a flashing "Drink " message on the LCD display
    unsigned short i;
    for (i = 0; i < 5; i++) 
    {
        
        LCD_cursor(0, 0);
        LCD_puts("Drink Dispensing");
        timer0_Delay(1);
        LCD_cursor(0, 0);
        LCD_puts("                            ");
        
    }
    
   
    PORTA = 0;
    return;
}


void dispenseChangeMode(void)
{ 
    unsigned short l;
       PORTA= 0x08;
    for (l = 0; l < 5; l++) 
    {  
        
        // Display message on LCD
        LCD_cursor(0, 0);
        LCD_puts("Change due: ");
        LCD_display_value(change_due);

        // Dispense change by setting LED output RA3 HIGH for 5 seconds
     
        Timer1Delay(1);   
    }  
    PORTA = 0;
    LCD_clear();
}


void drinkReadyMode(void)
{
    
    unsigned short j; // Declare a variable to use as a loop counter
    
    LCD_clear; // Clear the LCD display

    for(j=0; j<5; j++)// Loop five times, each time delaying for one second and displaying a message on the LCD display
    {
        Timer1Delay(1);// Delay for one second using the Timer1Delay() function
        
        // Display the message "Please Collect" on the first line of the LCD display
        LCD_cursor(0, 0);
        LCD_puts("Please Collect");
        
        // Display the message "Your Drink" on the second line of the LCD display
        LCD_cursor(0, 1);
        LCD_puts("Your Drink");
    }
}

